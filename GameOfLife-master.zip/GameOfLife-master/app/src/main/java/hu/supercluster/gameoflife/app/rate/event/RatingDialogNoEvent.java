package hu.supercluster.gameoflife.app.rate.event;

public class RatingDialogNoEvent {
}
