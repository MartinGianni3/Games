package hu.supercluster.gameoflife.game.event;

public class Restart {
}
