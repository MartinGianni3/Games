package hu.supercluster.gameoflife.game.event;

public class PaintWithBrush {
    public final int x;
    public final int y;

    public PaintWithBrush(int x, int y) {
        this.x = x;
        this.y = y;
    }
}
