package hu.supercluster.gameoflife.game.visualization.brush;

public interface Paintable {
    void paint(int x, int y, int state);
}
