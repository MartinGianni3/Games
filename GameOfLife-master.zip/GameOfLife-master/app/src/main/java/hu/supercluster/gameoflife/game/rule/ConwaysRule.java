package hu.supercluster.gameoflife.game.rule;

public class ConwaysRule extends NeighborCountBasedRule {
    public ConwaysRule() {
        super("23/3");
    }
}
