package hu.supercluster.gameoflife.game.visualization.cell;

import android.graphics.Paint;

public interface CellColors {
    Paint getPaint(int state);
}
