package com.bulsy.wbtempest;

/**
 * Created by ugliest on 2/28/15.
 */
public enum Sound {
    FIRE, ENEMYFIRE, CRAWLERMOVE, CRAWLERDEATH, ENEMYDEATH, LEVCHG, EXLIFE
}
